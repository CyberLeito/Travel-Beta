﻿using System.Web.UI;

namespace Travel_Beta.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}